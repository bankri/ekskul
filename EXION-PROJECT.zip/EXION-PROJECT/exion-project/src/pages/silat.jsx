import React from 'react';
import './silat.css';
export default function Silat() {
   (
    <div className="page">
      <h1>Ekskul Silat</h1>
      <p>Ekskul pencak silat mengembangkan keterampilan bela diri dan disiplin diri.</p>
    </div>
  );

  const anggota = [
    { nama: 'Andi Saputra', peran: 'Ketua', foto: 'https://via.placeholder.com/100' },
    { nama: 'Budi Santoso', peran: 'Wakil Ketua', foto: 'https://via.placeholder.com/100' },
    { nama: 'Citra Lestari', peran: 'Sekretaris', foto: 'https://via.placeholder.com/100' },
    { nama: 'Dina Rahmawati', peran: 'Bendahara', foto: 'https://via.placeholder.com/100' },
    { nama: 'Eko Prasetyo', peran: 'Anggota', foto: 'https://via.placeholder.com/100' },
  ];

  const achievements = [
    '🏆 Juara 1 Kejuaraan Silat Antar Sekolah se-Kota 2024',
    '🥇 Penghargaan Tim Terbaik di Festival Silat Nasional 2025',
  ];

  return (
    <div className="page">
      <h1>Ekskul Silat</h1>
      <p>Ekskul pencak silat mengembangkan keterampilan bela diri dan disiplin diri.</p>

      <h2>Anggota</h2>
      <div className="anggota-container">
        {anggota.map((a, index) => (
          <div key={index} className="card">
            <img src={a.foto} alt={a.nama} className="card-image" />
            <h3>{a.nama}</h3>
            <p>{a.peran}</p>
          </div>
        ))}
      </div>

      <h2>Achievements</h2>
      <ul className="achievement-list">
        {achievements.map((ach, index) => (
          <li key={index}>{ach}</li>
        ))}
      </ul>
    </div>
  );

}