export default function Futsal() {
  return (
    <div className="page">
      <h1>Ekskul Futsal</h1>
      <p>Ekskul futsal adalah kegiatan olahraga yang seru dan kompetitif di sekolah.</p>
    </div>
  );
}
