export default function Robotic() {
  return (
    <div className="page">
      <h1>Ekskul Robotic</h1>
      <p>Ekskul robotic mengajarkan pembuatan dan pemrograman robot.</p>
    </div>
  );
}
