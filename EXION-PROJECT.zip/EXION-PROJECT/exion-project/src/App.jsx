import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Futsal from "./pages/futsal";
import Musik from "./pages/musik";
import Robotic from "./pages/robotic";
import Silat from "./pages/silat";
import "./styles.css";

export default function App() {
  return (
    <Router>
      <header className="navbar">
        <nav>
          <Link to="/futsal">Futsal</Link>
          <Link to="/musik">Musik</Link>
          <Link to="/robotic">Robotic</Link>
          <Link to="/silat">Silat</Link>
        </nav>
      </header>

      <main>
        <Routes>
          <Route path="/futsal" element={<Futsal />} />
          <Route path="/musik" element={<Musik />} />
          <Route path="/robotic" element={<Robotic />} />
          <Route path="/silat" element={<Silat />} />
        </Routes>
      </main>
    </Router>
  );
}
