import React from 'react';

export default function Card({ name, role, bgColor }) {
  return (
    <div className="card" style={{ backgroundColor: bgColor }}>
      <h3>{name}</h3>
      <p>{role}</p>
    </div>
  );
}
