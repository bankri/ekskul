import React from 'react';
import Card from '../components/Card';
import '../index.css';

export default function Music() {
  return (
    <div className="page-container">
      <img className="logo" src="https://i.postimg.cc/QFJTTLrW/60754812-97cb-4fb3-89bc-264a6bf5f7bd.jpg" alt="Logo Music" />
      <h1>Ekskul Music</h1>
      <div className="cards-container">
        <Card name="Andi" role="Anggota" bgColor="#ff7f50" />
        <Card name="Budi" role="Anggota" bgColor="#ff7f50" />
        <Card name="Citra" role="Anggota" bgColor="#ff7f50" />
        <Card name="Dewi" role="Anggota" bgColor="#ff7f50" />
        <Card name="Eka" role="Anggota" bgColor="#ff7f50" />
      </div>
    </div>
  );
}
