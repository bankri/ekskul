import React from 'react';
import Card from '../components/Card';
import '../index.css';

export default function Futsal() {
  return (
    <div className="page-container">
      <img className="logo" src="https://i.postimg.cc/PNHCnXvs/3d661f3b-cff9-42b2-b573-1f4ab1acda42.jpg" alt="Logo Futsal" />
      <h1>Ekskul Futsal</h1>
      <div className="cards-container">
        <Card name="Putra" role="Anggota" bgColor="#ff6347" />
        <Card name="Qori" role="Anggota" bgColor="#ff6347" />
        <Card name="Rizal" role="Anggota" bgColor="#ff6347" />
        <Card name="Sinta" role="Anggota" bgColor="#ff6347" />
        <Card name="Toni" role="Anggota" bgColor="#ff6347" />
      </div>
    </div>
  );
}
