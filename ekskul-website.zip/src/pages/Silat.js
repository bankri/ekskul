import React from 'react';
import Card from '../components/Card';
import '../index.css';

export default function Silat() {
  return (
    <div className="page-container">
      <img className="logo" src="https://i.postimg.cc/t1L955WG/c1e6ec8c-4413-4fa8-a50c-0f5e5a20b121.jpg" alt="Logo Silat" />
      <h1>Ekskul Silat</h1>
      <div className="cards-container">
        <Card name="Fajar" role="Anggota" bgColor="#2e8b57" />
        <Card name="Gilang" role="Anggota" bgColor="#2e8b57" />
        <Card name="Hadi" role="Anggota" bgColor="#2e8b57" />
        <Card name="Indra" role="Anggota" bgColor="#2e8b57" />
        <Card name="Joko" role="Anggota" bgColor="#2e8b57" />
      </div>
    </div>
  );
}
