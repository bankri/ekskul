import React from 'react';
import Card from '../components/Card';
import '../index.css';

export default function Robotic() {
  return (
    <div className="page-container">
      <img className="logo" src="https://i.postimg.cc/5j5fB8tD/ac0c7586-b9df-4d17-897e-5d42330f36a7.jpg" alt="Logo Robotic" />
      <h1>Ekskul Robotic</h1>
      <div className="cards-container">
        <Card name="Kevin" role="Anggota" bgColor="#4682b4" />
        <Card name="Lina" role="Anggota" bgColor="#4682b4" />
        <Card name="Maya" role="Anggota" bgColor="#4682b4" />
        <Card name="Nina" role="Anggota" bgColor="#4682b4" />
        <Card name="Oscar" role="Anggota" bgColor="#4682b4" />
      </div>
    </div>
  );
}
