import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Silat from './pages/Silat';
import Futsal from './pages/Futsal';
import Music from './pages/Music';
import Robotic from './pages/Robotic';
import './index.css';

function App() {
  return (
    <Router>
      <nav className="navbar">
        <Link to="/music">Music</Link>
        <Link to="/silat">Silat</Link>
        <Link to="/futsal">Futsal</Link>
        <Link to="/robotic">Robotic</Link>
      </nav>
      <Routes>
        <Route path="/" element={<Music />} />
        <Route path="/music" element={<Music />} />
        <Route path="/silat" element={<Silat />} />
        <Route path="/futsal" element={<Futsal />} />
        <Route path="/robotic" element={<Robotic />} />
      </Routes>
    </Router>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
